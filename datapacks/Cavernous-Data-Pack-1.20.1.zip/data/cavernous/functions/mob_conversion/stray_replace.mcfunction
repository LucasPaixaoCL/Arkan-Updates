summon stray ~ ~ ~
execute at @s run function cavernous:mob_conversion/stray_data
execute on vehicle run function cavernous:mob_conversion/vehicle
tp @s ~ ~-200 ~